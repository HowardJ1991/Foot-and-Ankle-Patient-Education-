
import React from 'react';
import type { Category, Topic } from '../types';
import { ChevronLeftIcon } from './icons/ChevronLeftIcon';

const ContentSkeleton: React.FC = () => (
  <div className="space-y-8 animate-pulse mt-4">
    <div className="space-y-4">
        <div className="h-8 bg-gray-200 rounded w-3/4"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
        <div className="h-4 bg-gray-200 rounded w-5/6"></div>
    </div>
    <div className="space-y-4">
        <div className="h-8 bg-gray-200 rounded w-1/2"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
        <div className="h-4 bg-gray-200 rounded w-4/6"></div>
    </div>
    <div className="space-y-4">
        <div className="h-8 bg-gray-200 rounded w-2/3"></div>
        <div className="h-4 bg-gray-200 rounded w-full"></div>
    </div>
  </div>
);

interface ContentViewerProps {
  category: Category;
  topic: Topic;
  content: string;
  isLoading: boolean;
  error: string | null;
  onBack: () => void;
  onRetry: () => void;
}

const SimpleMarkdownParser: React.FC<{ text: string }> = ({ text }) => {
  const lines = text.split('\n');
  const elements: React.ReactNode[] = [];
  let listItems: React.ReactNode[] = [];

  const flushList = (key: string) => {
    if (listItems.length > 0) {
      elements.push(<ul key={key} className="list-disc pl-6 space-y-2 my-4">{listItems}</ul>);
      listItems = [];
    }
  };

  lines.forEach((line, index) => {
    if (line.startsWith('### ')) {
      flushList(`ul-${index}`);
      elements.push(<h3 key={`h3-${index}`} className="text-2xl font-bold mt-8 mb-3 text-brand-dark border-b-2 border-brand-lightblue pb-2">{line.substring(4)}</h3>);
    } else if (line.startsWith('* ')) {
      listItems.push(<li key={`li-${index}`}>{line.substring(2)}</li>);
    } else if (line.trim() === '') {
      flushList(`ul-${index}`);
      // Don't render a spacer for every blank line to avoid excessive whitespace
    } else {
      flushList(`ul-${index}`);
      elements.push(<p key={`p-${index}`} className="leading-relaxed mb-4">{line}</p>);
    }
  });

  flushList('ul-last');

  return (
    <div className="prose lg:prose-lg max-w-none text-gray-800">
      {elements}
    </div>
  );
};

const ContentViewer: React.FC<ContentViewerProps> = ({ category, topic, content, isLoading, error, onBack, onRetry }) => {
  return (
    <div className="animate-fade-in">
       <div className="flex items-center mb-6">
        <button
          onClick={onBack}
          className="p-2 rounded-full hover:bg-gray-200 transition-colors duration-200 mr-4"
          aria-label="Back to topics"
        >
          <ChevronLeftIcon className="h-6 w-6 text-brand-gray" />
        </button>
        <div>
            <p className="text-sm text-brand-gray">{category}</p>
            <h2 className="text-2xl sm:text-3xl font-bold text-brand-dark">{topic}</h2>
        </div>
      </div>

      {isLoading && <ContentSkeleton />}
      
      {error && (
        <div className="text-center py-10 px-4 bg-red-50 border border-red-200 rounded-lg">
          <svg className="mx-auto h-12 w-12 text-red-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" aria-hidden="true">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
          </svg>
          <h3 className="mt-2 text-lg font-semibold text-red-800">An Error Occurred</h3>
          <p className="mt-2 text-sm text-red-600">{error}</p>
          <button
            onClick={onRetry}
            className="mt-6 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-brand-blue hover:bg-brand-blue/90 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-brand-blue"
          >
            Try Again
          </button>
        </div>
      )}

      {!isLoading && !error && content && (
        <div className="mt-4">
          <SimpleMarkdownParser text={content} />
        </div>
      )}
    </div>
  );
};

export default ContentViewer;
