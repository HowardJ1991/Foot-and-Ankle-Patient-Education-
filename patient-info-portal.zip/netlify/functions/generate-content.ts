import { GoogleGenAI } from "@google/genai";
import type { Handler } from "@netlify/functions";

// This function securely gets the Google AI client using the API_KEY from Netlify's environment variables.
const getClient = (): GoogleGenAI => {
  const apiKey = process.env.API_KEY;
  if (!apiKey) {
    // If the key is missing in Netlify settings, throw an error that will be shown in the app.
    throw new Error("API Key not configured by the site administrator.");
  }
  return new GoogleGenAI({ apiKey });
};

// This is the main handler for our serverless function.
const handler: Handler = async (event) => {
  // Only allow POST requests.
  if (event.httpMethod !== "POST") {
    return {
      statusCode: 405,
      body: JSON.stringify({ error: "Method Not Allowed" }),
    };
  }

  try {
    // Get the topic from the request sent by the app.
    const { topic } = JSON.parse(event.body || "{}");

    if (!topic) {
      return {
        statusCode: 400,
        body: JSON.stringify({ error: "Topic is required" }),
      };
    }

    // This is the same prompt we used before.
    const prompt = `
    You are a helpful assistant for a foot and ankle surgeon's office. Your purpose is to provide clear, easy-to-understand educational material for patients.
    
    The topic is: "${topic}".

    Write for a general audience with no medical background. Avoid overly technical jargon. Use simple language.
    
    Structure your response with the following sections if they are applicable to the topic:
    - ### What is it? (A simple overview)
    - ### Common Symptoms
    - ### What Causes It?
    - ### Common Treatment Options (Briefly describe non-surgical and surgical options like physical therapy, orthotics, medication, lifestyle changes, and surgery, without recommending one over the other. Frame them as possibilities to discuss with a doctor.)
    - ### What Can I Do at Home? (Suggest general, safe, at-home care.)

    Format the response using markdown. Use "###" for section headings and "*" for bullet points in lists.
    
    IMPORTANT: Conclude your response with the following exact disclaimer, on its own line, at the very end:
    "This information is for educational purposes only and does not constitute medical advice. Please consult with your surgeon to discuss your specific condition and treatment plan."
  `;

    // Securely initialize the AI client and make the API call.
    const ai = getClient();
    const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: prompt,
    });
    
    const text = response.text;

    // Send the generated content back to the app in a JSON response.
    return {
      statusCode: 200,
      body: JSON.stringify({ content: text }),
      headers: { 'Content-Type': 'application/json' },
    };

  } catch (error) {
    console.error("Error in Netlify function:", error);
    const errorMessage = error instanceof Error ? error.message : "An internal server error occurred.";
    return {
      statusCode: 500,
      body: JSON.stringify({ error: `Server error: ${errorMessage}` }),
      headers: { 'Content-Type': 'application/json' },
    };
  }
};

export { handler };
