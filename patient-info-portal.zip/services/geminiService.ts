import type { Topic } from '../types';

export const fetchTopicInfo = async (topic: Topic): Promise<string> => {
  try {
    // This now calls our own secure backend function instead of Google's API directly.
    const response = await fetch('/api/generate-content', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ topic }),
    });

    // Handle errors from our backend function (e.g., if the API key is missing).
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({ error: `Request failed with status ${response.status}` }));
      throw new Error(errorData.error || `Request failed with status ${response.status}`);
    }

    const data = await response.json();
    return data.content;

  } catch (error) {
    console.error("Error fetching data from backend function:", error);
    if (error instanceof Error) {
        // Prepend a user-friendly message to the technical error for better UI feedback.
        throw new Error(`Failed to get information. Reason: ${error.message}`);
    }
    throw new Error("An unknown error occurred while fetching information.");
  }
};
